package Model;

import Dao.Identifier;
import javax.persistence.Entity;

@Entity
public class Administrador extends Pessoa implements Identifier{

    
    public Administrador(){
        
    }
}
