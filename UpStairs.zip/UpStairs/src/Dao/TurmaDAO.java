package Dao;

import Model.Turma;

/**
 *
 * @author thaia
 */
public class TurmaDAO extends GenericDAOImp<Turma> {
    
}
