package Dao;

import Model.Nota;

/**
 *
 * @author thaia
 */
public class NotaDAO extends GenericDAOImp<Nota> {
    
}
