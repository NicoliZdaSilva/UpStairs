package Dao;

public class DaoCadastroAdministrador extends Dao {
    
}
