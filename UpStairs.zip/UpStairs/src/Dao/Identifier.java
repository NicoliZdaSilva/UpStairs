package Dao;

/**
 *
 * @author thaia
 */
public interface Identifier {
    
    long getId();
}
