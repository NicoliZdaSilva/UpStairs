package Dao;

public class DaoCadastroAluno extends Dao {
    
}
